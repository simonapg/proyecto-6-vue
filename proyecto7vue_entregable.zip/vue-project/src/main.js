import './assets/scss/main.scss'

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

store.dispatch('auth/inicializarSesion')

createApp(App).use(store).use(router).mount('#app')
